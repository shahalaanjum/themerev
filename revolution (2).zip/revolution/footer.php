<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Revolution
 * @since Revolution 1.0
 */
?>	
		<footer id="colophon" role="contentinfo">
			<div class="container">
				<div class="bottom-footer">
				<?php
					echo do_shortcode(get_field('copyright_text','option'));
					echo do_shortcode('[sociallinks]');
				?>
				</div>
			</div>	
		</footer><!-- #colophon -->
	</div><!-- #page -->
	<!-- <?php //if(options('scroll_to_top_link') == '1'):?>
		<div id="top" onclick="toTop();"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i></div>
	<?php// endif; ?> -->
	<?php wp_footer(); ?>
	</body>
</html>
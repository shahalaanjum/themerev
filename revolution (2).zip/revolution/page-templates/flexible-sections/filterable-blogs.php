<?php
    $remove_top_spacing = get_sub_field('remove_top_spacing');
    $remove_bottom_spacing = get_sub_field('remove_bottom_spacing');
    if($remove_top_spacing){
        $remove_top_spacing_cl = 'remove-top-spacing';
    } else{
        $remove_top_spacing_cl ='';
    }

    if($remove_bottom_spacing){
        $remove_bottom_spacing_cl = 'remove-bottom-spacing';
    } else{
        $remove_bottom_spacing_cl ='';
    }
$show_filters = get_sub_field('show_filters');
$next_button_label = get_sub_field('next_button_label');
$previous_button_label = get_sub_field('previous_button_label');

if($show_filters){ ?>
    <section class="news_blog_category_sec <?php echo $remove_bottom_spacing_cl.' '.$remove_top_spacing_cl; ?>">
        <div class="container">
            <div class="categories-list-dropdown filter--sidebar">
                <input type="hidden" id="filters-category" />
                <input type="hidden" id="filters-tag" />
                <input type="hidden" id="filters-order" />
                
                <?php 
                    $categories = get_categories(array('hide_empty => 0',
                    'exclude' => 1,
                )); 
                    $tags = get_tags('hide_empty=0'); 
                    ?>
                <div class="dropdwn-filters-blog wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                    

                    <select name="tags" id="dropDownId" class="cat-list filter-dropdown">
                    <option value="" class="cat-list_item" data-slug="" data-type="category" data-id="">All Tags</option>
                        <?php foreach($tags as $tag) : ?>
                        <option value="<?= $tag->term_id; ?>" class="cat-list_item" data-slug="<?= $tag->slug; ?>" data-type="category" data-id="<?= $tag->term_id; ?>"><?= $tag->name; ?></option>
                        <?php endforeach; ?>
                    </select>

                    <select name="sort" id="sortdropDownId" class="sort-list filter-dropdown">
                        <option value="DESC" class="sort-list_item" data-slug="DESC" data-type="order" data-id="DESC">Most Recent</option>
                        <option value="ASC" class="sort-list_item" data-slug="ASC" data-type="order" data-id="ASC">Most Oldest</option>
                    </select>
                </div>


               
                <ul class="tag-list wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                    <li><a href="javascript:;" class="filter-link tag-list_item " data-type="tag" data-slug="" data-id="">All</a></li>
                    <?php foreach($categories as $category) : ?>
                        <li>
                            <a href="javascript:;" class="filter-link tag-list_item" data-slug="<?= $category->slug; ?>" data-type="tag" data-id="<?= $category->term_id; ?>">
                                <?= $category->name; ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
                

            </div>
        </div>
    </section>
<?php }

    $projects = new WP_Query([
        'post_type' => 'post',
        'posts_per_page' => 8,
        'orderby'        => 'publish_date',
        'order'     => 'DESC' ,

    ]);
    $counter = $projects->max_num_pages;
?>
<section class="news_blog_module_sec">
    <div class="container projects-grid">
        <?php if($projects->have_posts()): ?>
            <div class="news_blog_module_list_wrap project-tiles">
                <?php while($projects->have_posts()) : $projects->the_post(); ?>
                    <div class="news_blog_module_list wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                        <figure class="news_blog_img" style="background-image: url(<?php 
                        echo get_field('featured_image'); 
                        // echo wp_get_attachment_url(get_field('featured_image')); 
                        ?>);">
                            <!-- IMage define in BG -->
                            <a href="<?php echo get_permalink(); ?>" title=""><!--link Define Here --></a>
                        </figure>
                        <?php
                        $postcategories = get_the_category();
                        $category_list = join( ', ', wp_list_pluck( $postcategories, 'name' ) ); 
                        ?>
                        <h5><?php echo wp_kses_post( $category_list );  ?></h5>
                        <h3><a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
                        <span class="post-date"><?php echo get_the_date('d F Y'); ?></span>
                    </div>
                <?php endwhile; ?>
            </div>

            <div class="pagination wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                <div id="more_prev_posts"><?php echo($previous_button_label )? $previous_button_label :'❮'; ?></div>
                <div class='page-nav-container'>
                    <?php
                        // Get max pages and current page out of the current query, if available.
                        $currentp = get_query_var( 'paged' ) ? (int) get_query_var( 'paged' ) : 1;
                        echo $current = 'Page <span class="current-page">'.$currentp.'</span>';
                        echo 'of';
                        echo $total   = isset( $projects->max_num_pages ) ? '<span class="max-page">'.$projects->max_num_pages.'</span>' : 1; 
                    ?>
                </div>
                <div id="more_blog_posts"><?php echo($next_button_label )? $next_button_label :'❯'; ?></div>
            </div>
            <?php
            wp_reset_postdata(); ?>
            
        <?php endif; ?>
    </div>
</section>
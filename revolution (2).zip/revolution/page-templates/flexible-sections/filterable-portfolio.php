<?php
/**
 * filterable portfolio section
 * author : UP0758
 */

 
get_header();
$remove_top_spacing = get_sub_field('remove_top_spacing');
$remove_bottom_spacing = get_sub_field('remove_bottom_spacing');
if($remove_top_spacing){
    $remove_top_spacing_cl = 'remove-top-spacing';
} else{
    $remove_top_spacing_cl ='';
}

if($remove_bottom_spacing){
    $remove_bottom_spacing_cl = 'remove-bottom-spacing';
} else{
    $remove_bottom_spacing_cl ='';
}

$portfolio_display_type = get_sub_field('portfolio_display_type');
$title_and_subtitle = get_sub_field('title_and_subtitle');
$show_filters = get_sub_field('show_filters');
$select_projects = get_sub_field('select_projects');
$button = get_sub_field('button');
if($button && $button['target']){
    $target = '_blank';
} else{
    $target = '_self';
}
$load_more_button = get_sub_field('load_more_button');
if($portfolio_display_type == 'Grid'){
?>
<section class="portfolio_filter_module_sec <?php echo $remove_bottom_spacing_cl.' '.$remove_top_spacing_cl; ?>">
    <div class="container">
        <?php if($show_filters ){ ?>
        <div class="portfolio-categories-list wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
            <input type="hidden" id="filters-category" />
            
            <?php $categories = get_terms( 'portfolio_category', 'hide_empty=0'); 
        
            ?>
            <ul class="portfolio-cat-list">
                <li><a href="javascript:;" class="portfolio-cat-item cat-list_item active" data-slug="">All </a></li>
        
                <?php foreach($categories as $category) : ?>
                    <li class="wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                        <a href="javascript:;" class="portfolio-cat-item cat-list_item" data-slug="<?= $category->slug; ?>" data-type="category" data-id="<?= $category->term_id; ?>">
                            <?= $category->name; ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php } ?>
        <div class="projects-grid">
            <?php 
            $projects = new WP_Query([
                'post_type' => 'portfolio',
                'posts_per_page' => 6,
                
            ]);
            ?>
            <div class="count" id="result-count"></div>
            <?php if($projects->have_posts()): ?>
                <ul class="project-tiles-portfolio">
                    <?php
                    while($projects->have_posts()) : $projects->the_post();
                        echo '<li class="wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">';
                            get_template_part('page-templates/page/content/content-portfolio', 'page');
                            
                        echo '</li>';
                    endwhile;
                    ?>
                </ul>
                <?php wp_reset_postdata(); 
                echo ($load_more_button) ? '<div id="more_posts">'.$load_more_button.'</div>' : ' <div id="more_posts"> > </div>' ;
                ?>
                
            <?php endif; ?>
        </div>
    </div>
</section>
<?php } else{
    if($title_and_subtitle || $select_projects || $button){
    ?>
    <section class="our_portfolio_module_sec">
        <div class="container">
            <?php
                echo ($title_and_subtitle) ? '
                <div class="modules_content wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                    '.$title_and_subtitle.'
                </div>' : '' ;
                if($select_projects){ 
                    echo '<div class="our_portfolio_module_slider wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">';
                        foreach($select_projects as $item){
                            $thum_img = get_the_post_thumbnail_url($item);
                            $post_title = get_the_title($item);
                            $post_excerpt = get_the_excerpt($item);
                            if($thum_img || $post_excerpt || $post_title){
                            ?>
                                <div>
                                    <div class="our_portfolio_module_content" style="background-image: url(<?php echo $thum_img; ?>)">
                                        <div class="our_portfolio_module_content_inner">
                                            <h3><?php echo $post_title; ?></h3>
                                            <?php echo $post_excerpt; ?>
                                        </div>
                                    </div>
                                    <div class="our_portfolio_module_content_inner">
                                            <h3><?php echo $post_title; ?></h3>
                                            <?php echo $post_excerpt; ?>
                                    </div>
                                </div>
                            <?php }
                        }
                    echo '</div>';
                } 

                echo ($button) ? '
                <div class="text-center wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.5s">
                    <a href="'.$button['url'].'" title="'.$button['title'].'" class="primary_btn" target="'.$target.'">'.$button['title'].'</a>
                </div>' : '' ;
                ?>
            
        </div>
    </section>
<?php }
} ?>

<?php
/**
 * Template Name: Flexible Layout
 * author : UP0758
 */

 
get_header();

// while ( have_posts() ) :
//     the_post(); 
//     if( have_rows('page_blocks') ):
//         while ( have_rows('page_blocks') ) : the_row();
        
//             if( get_row_layout() == 'call_to_action_module' ):
//                 get_template_part( 'flexible-sections/cta_banner' );
//             endif; 
    
//         endwhile;
//     endif; 
// endwhile;
 
    while ( have_posts() ) : the_post(); 
		echo do_shortcode( '[flexlayout name=page_blocks]' );
	endwhile; 

get_footer();
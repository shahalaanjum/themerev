<?php
//netstrata customization starts here

//disabling gutenberg
add_filter('use_block_editor_for_post', '__return_false', 10);

//The PHP WordPress Filter,

function filter_blogs() {
	$catIds = isset($_POST['catIds']) ? sanitize_text_field($_POST['catIds']) : '' ;
	$tagIds = isset($_POST['tagIds']) ? sanitize_text_field($_POST['tagIds']) : ''  ;
	$sortOrder = isset($_POST['sortOrder']) ? sanitize_text_field($_POST['sortOrder']) : '' ;
	$page = (isset($_POST['pageNumber'])) ? $_POST['pageNumber'] : 0;
	$args = [
		'post_type' => 'post',
		'posts_per_page' => 8,
		'post_status'  => 'publish',
		'orderby'        => 'publish_date',
		'order'     => $sortOrder ,
		'paged'    => $page,
		'tax_query' => array('relation' => 'OR',),
	];
	// project Category
	if (!empty($catIds)) {
		$args['tax_query'][] = [
			'taxonomy'      => 'category',
			'field'			=> 'term_id',
			'terms'         => $catIds,
			'operator'      => 'IN'
		];
	}
	// project tag 
	
	if (!empty($tagIds)) {
		$args['tax_query'][] = [
			'taxonomy'      => 'post_tag',
			'field'			=> 'term_id',
			'terms'         => $tagIds,
			'operator'      => 'IN'
		];
	}
	$response = '';
	$ajaxproducts = new WP_Query($args);
	if ( $ajaxproducts->have_posts() ) {
		ob_start();
		while ( $ajaxproducts->have_posts() ) : $ajaxproducts->the_post();
			// $response = get_template_part('page-templates/page/content/content', 'page');
            //echo $response = get_the_title().','; ?>
				<div class="news_blog_module_list">
					<figure class="news_blog_img" style="background-image: url(<?php  
					echo get_field('featured_image');
					//  wp_get_attachment_url(get_field('featured_image'));
					  ?>);">
						<!-- IMage define in BG -->
						<a href="<?php echo get_permalink(); ?>" title=""><!--link Define Here --></a>
					</figure>
					<?php
					$postcategories = get_the_category();
					$category_list = join( ', ', wp_list_pluck( $postcategories, 'name' ) ); 
					?>
					<h5><?php echo wp_kses_post( $category_list );  ?></h5>
					<h3><a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
					<span class="post-date"><?php echo get_the_date('d F Y'); ?></span>
				</div>
		<?php
		endwhile;
		$output = ob_get_contents();
		ob_end_clean();
	} else {
        $output = '<h1 class="no-posts">No posts found</h1>' ;
		$no_projects = 1;
	}
	$current = get_query_var( 'paged' ) ? (int) get_query_var( 'paged' ) : 1;
	$total   = isset( $ajaxproducts->max_num_pages ) ? $ajaxproducts->max_num_pages : 1;
    $counter = $ajaxproducts->max_num_pages;
	$result = [
		'current' => $current,
		'total'   => $total,
		'html' => $output,
		'no_projects' => $no_projects,
	];
	
	echo json_encode($result);
	wp_reset_postdata();
	exit;
}
add_action('wp_ajax_filter_blogs', 'filter_blogs');
add_action('wp_ajax_nopriv_filter_blogs', 'filter_blogs');
 

//portfoio filter code start

function filter_projects() {

	$response = array(		
		"status" => false,		
		"html" => "");	
	$catSlug =isset($_POST['portfoliocategory']) ? sanitize_text_field($_POST['portfoliocategory']) : '' ;

    $page = (isset($_POST['pageNumber'])) ? $_POST['pageNumber'] : 0;
	$args = [
		'post_type' => 'portfolio',
		'orderby' => 'menu_order', 
		'order' => 'desc',
		'posts_per_page' => 4,
        'paged'    => $page,
	];
	 // project Category
	if (!empty($catSlug)) {
		$args['tax_query'][] = [
			'taxonomy' => 'portfolio_category',
			'field'    => 'slug',
			'terms'    => $catSlug,
			'operator' => 'IN',
		];
	 }	
	$ajaxprojects = new WP_Query($args);			
	$response['load_more'] = $page < $ajaxprojects->max_num_pages ? "true" : "false";	
	$response['next_page'] = $page+1;	
	$response['found_posts'] = $ajaxprojects->found_posts . " " . ( $ajaxprojects->found_posts <= 1 ? " result found" : " results found" ) ;			
	ob_start();
	if($ajaxprojects->have_posts()) 	{		
		$response['status'] = true;
		while($ajaxprojects->have_posts()) 		{ 			
			$ajaxprojects->the_post();
			get_template_part('page-templates/page/content/ajax-portfolio', 'page');
		
		}
	}	else	{
		echo '<h1 class="no-posts">No Posts Found</h1>';
	}
	$output = ob_get_contents();	
	$response['html'] = $output;	
	ob_get_clean();
	echo json_encode($response);
	exit;
}
  add_action('wp_ajax_filter_projects', 'filter_projects');
  add_action('wp_ajax_nopriv_filter_projects', 'filter_projects');

  //portfoio filter code end


  //search form in resources
  function wpbsearchform( $form ) {
	$input_placeholder_text = get_sub_field('input_placeholder_text');
    $button_label = (get_sub_field('button_label'))? get_sub_field('button_label') : '❯' ;
    $form = '<div id="search-container">
	<form role="search" method="get" id="resource_searchform" action="' . home_url( '/' ) . '" >
    <div><label class="screen-reader-text" for="s">' . __('Search for:') . '</label>
    <input type="text" value="' . sanitize_text_field(esc_html(get_search_query())) . '" name="s" id="s" placeholder="'.$input_placeholder_text.'"/>
    <input type="submit" id="resource_searchsubmit" value="'. esc_attr__($button_label) .'" />
    </div>
    </form></div>';
   
    return $form;
}
   
add_shortcode('wpbsearch', 'wpbsearchform');



// search form ajax request function


function load_search_results() {
    $query = isset($_POST['query']) ? sanitize_text_field(esc_html($_POST['query'])) : '' ;
    $content ='';
    $args = array(
        'post_type' => 'resources',
        'post_status' => 'publish',
        's' => $query
    );
    $search = new WP_Query( $args );
    if ( $search->have_posts() ) :
			while ( $search->have_posts() ) : $search->the_post();
				$post_id = get_the_ID();
				$resource_icon = get_field('resource_icon', $post_id);
				$r_excerpt = get_the_excerpt($post_id);
				$r_title = get_the_title($post_id);
				if($r_title || $excerpt || $resource_icon){
					$content .= '<div class="resources_topics_list">';
						$content .= ($resource_icon)?'
							<figure>
								<img src="'.$resource_icon.'" alt="" />
							</figure>
						' : '';
						$content .= '<div class="resources_topics_content">';
							$content .= ($r_title) ? '<h4>'.$r_title.'</h4>' :'';
							$content .= ($r_excerpt) ? '<p>'.$r_excerpt.'</p>' :'';
						$content .= '</div>';
					$content .= '</div>';
				}
			endwhile; 
	else :
		$content .= '<h1 class="no-posts">No posts found</h1>';
	endif;
	$return['html'] = $content;
      echo json_encode($return);
      die;
			
}

add_action( 'wp_ajax_load_search_results', 'load_search_results' );
add_action( 'wp_ajax_nopriv_load_search_results', 'load_search_results' );


// to return jsvoid(0) a tag

if(!function_exists('expLink')){
    function expLink($link){
        if($link == '#'){
            return 'javascript:void(0);';
        }
		$link = esc_url($link);
        return $link;
    }
}

//Automatically Set the First Post Image as a Featured Image in WordPress
// function auto_featured_image() {
//     global $post;
 
//     if (!has_post_thumbnail($post->ID)) {
//         $attached_image = get_children( "post_parent=$post->ID&amp;post_type=attachment&amp;post_mime_type=image&amp;numberposts=1" );
         
//       if ($attached_image) {
//               foreach ($attached_image as $attachment_id => $attachment) {
//                    set_post_thumbnail($post->ID, $attachment_id);
//               }
//          }
//     }
// }
// // Use it temporary to generate all featured images
// add_action('the_post', 'auto_featured_image');
// // Used for new posts
// add_action('save_post', 'auto_featured_image');
// add_action('draft_to_publish', 'auto_featured_image');
// add_action('new_to_publish', 'auto_featured_image');
// add_action('pending_to_publish', 'auto_featured_image');
// add_action('future_to_publish', 'auto_featured_image');
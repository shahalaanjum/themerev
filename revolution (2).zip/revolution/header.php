<?php
/**
 * Header file for the Twenty Twenty WordPress default theme.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Revolution
 * @since Revolution 1.0
 */

?><!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="profile" href="http://gmpg.org/xfn/11" />
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />		
		<?php wp_head(); ?>		
		<?php //head_section_script(); ?>
	</head>

	<body <?php body_class(); ?>>
		<?php // site_loader(); ?>
		<?php //scipt_print_in_body(); ?>
		<?php wp_body_open(); ?>

		<div id="page" class="hfeed site">			
			<header id="masthead" class="site-header">	
				<div class="main-header container">
					<div class="row">
						<div class="col-12 col-lg-4">
							<?php // logo_header(); 	?>
							<!-- hamburger start -->
							<div class="hamburger hamburger--3dxy-r">
							    <div class="hamburger-box">
							    	<div class="hamburger-inner"></div>
								</div>
							</div>
							<!-- hamburger end -->
						</div>
						<nav id="site-navigation" class="top-nav main-navigation col-12 col-lg-8 my-auto">				
							<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
						</nav><!-- #site-navigation -->
					</div>
				</div>
			</header><!-- #masthead -->